Resources for the system
